<?php
include_once dirname(__FILE__) . '/bwp-minify/bwp-minify.php';
